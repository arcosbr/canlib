var searchData=
[
  ['helper_20functions',['Helper functions',['../group___helper.htm',1,'']]]
];
