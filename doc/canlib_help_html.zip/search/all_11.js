var searchData=
[
  ['real_20time_20clock',['Real Time Clock',['../group__kvm__rtc.htm',1,'']]],
  ['receive_20and_20reply_20to_20can_20message',['Receive and reply to CAN message',['../page_example_c_echo.htm',1,'page_user_guide_canlib_samples']]],
  ['remote_20device_20api_20_28kvrlib_29',['Remote Device API (kvrlib)',['../page_kvrlib.htm',1,'']]],
  ['request_5fconnection',['request_connection',['../kvrlib_8h.htm#a2d0ed331650715b2758668e03c6ecd2c',1,'kvrDeviceInfo']]],
  ['reserved',['reserved',['../j1587lib_8h.htm#a3415ebf9c5050a50fa3ae127df65e763',1,'J1587MessageInfo']]],
  ['reserved1',['reserved1',['../kvrlib_8h.htm#ae67e2c0ec4e8c9e9504a0f38e7415084',1,'kvrDeviceInfo']]],
  ['reserved2',['reserved2',['../kvrlib_8h.htm#a42a59db44a2f07b7fcbe7c4de3f7cba7',1,'kvrDeviceInfo']]],
  ['right',['right',['../kvamemolibxml_8h.htm#afa54f74105f850a372148e16dde90651',1,'tag_token']]],
  ['ro1',['RO1',['../canlib_8h.htm#a51f47034125d484b8a7d13e414f2854a',1,'kvIoModuleRelay']]],
  ['ro2',['RO2',['../canlib_8h.htm#a74ec56c96381bdbac5979ca55f1f6c81',1,'kvIoModuleRelay']]],
  ['ro3',['RO3',['../canlib_8h.htm#a5b25e1ffac3bdd23e1b7be606abfd437',1,'kvIoModuleRelay']]],
  ['ro4',['RO4',['../canlib_8h.htm#ab3f579cac16905edf55011dcc2e9090a',1,'kvIoModuleRelay']]],
  ['ro5',['RO5',['../canlib_8h.htm#a2a2866e10a2945ebd13e09bcbb57cd52',1,'kvIoModuleRelay']]],
  ['ro6',['RO6',['../canlib_8h.htm#ac8627cecb81615ec17028f05c2faf449',1,'kvIoModuleRelay']]],
  ['ro7',['RO7',['../canlib_8h.htm#a459a1901794b9ff25b154c25696a14c4',1,'kvIoModuleRelay']]],
  ['ro8',['RO8',['../canlib_8h.htm#a9fcce63e7449e5adb9ae98deaaf5efee',1,'kvIoModuleRelay']]],
  ['rxbufsize',['rxBufSize',['../group___obsolete.htm#a22031cf318e44e0c0d51be474623e6f5',1,'tagCanSWDescr::rxBufSize()'],['../group___obsolete.htm#a22031cf318e44e0c0d51be474623e6f5',1,'canSWDescriptorEx::rxBufSize()']]]
];
