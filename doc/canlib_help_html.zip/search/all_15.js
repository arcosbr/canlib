var searchData=
[
  ['validation',['Validation',['../group__kvaxml__validation.htm',1,'']]],
  ['vector_20ascii_20_28r_2fw_29',['Vector ASCII (R/W)',['../kvlclib_format__v_e_c_t_o_r__a_s_c.htm',1,'kvlclib_formats']]],
  ['vector_20blf_20_28w_29',['Vector BLF (W)',['../kvlclib_format__v_e_c_t_o_r__b_l_f.htm',1,'kvlclib_formats']]],
  ['vector_20blf_20fd_20_28r_2fw_29',['Vector BLF FD (R/W)',['../kvlclib_format__v_e_c_t_o_r__b_l_f__f_d.htm',1,'kvlclib_formats']]],
  ['version_20checking',['Version Checking',['../page_user_guide_version.htm',1,'page_canlib']]],
  ['version',['version',['../canlib_8h.htm#aad880fc4455c253781e8968f2239d56f',1,'kvClockInfo::version()'],['../canlib_8h.htm#aad880fc4455c253781e8968f2239d56f',1,'kvBusParamLimits::version()'],['../j1587lib_8h.htm#a278ac8112eb4d891fdffa2a26fb4de69',1,'J1587MessageInfo::version()'],['../kvrlib_8h.htm#acd99bb05ca015e7d74448acb1deba7ca',1,'kvrCipherInfoElement::version()']]],
  ['version_5fmajor',['version_major',['../kv_diag_8h.htm#a127884f2f1eab0890886401341e3c895',1,'kvAnalyzerInfo_t']]],
  ['version_5fminor',['version_minor',['../kv_diag_8h.htm#a572faf2098c53a548a02485a12c3a493',1,'kvAnalyzerInfo_t']]]
];
