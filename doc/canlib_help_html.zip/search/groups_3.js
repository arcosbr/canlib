var searchData=
[
  ['file_20handling',['File Handling',['../group__grp__kvfile.htm',1,'']]],
  ['file_20operations',['File Operations',['../group__kvm__files.htm',1,'']]]
];
