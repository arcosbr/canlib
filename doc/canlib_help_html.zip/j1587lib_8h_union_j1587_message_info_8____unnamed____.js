var j1587lib_8h_union_j1587_message_info_8____unnamed____ =
[
    [ "checkSum", "j1587lib_8h.htm#ad631ce67859679147a3c2956651559a5", null ],
    [ "retries", "j1587lib_8h.htm#af31fb46f46b20faf646ff94e9095dfa8", null ]
];