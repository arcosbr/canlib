var NAVTREE =
[
  [ "Welcome to Kvaser CANlib SDK!", "index.htm", [
    [ "Installation", "page_installing.htm", "page_installing" ],
    [ "Kvaser Support", "page_support.htm", null ],
    [ "License and Copyright", "page_license_and_copyright.htm", null ],
    [ "Compiling and Compatibility", "page_user_guide_build.htm", "page_user_guide_build" ],
    [ "Tutorials", "page_tutorial.htm", "page_tutorial" ],
    [ "CAN bus API (CANlib)", "page_canlib.htm", "page_canlib" ],
    [ "LIN bus API (LINlib)", "page_linlib.htm", [
      [ "Description", "page_linlib.htm#section_user_guide_lin_lib_1", null ],
      [ "Using the LIN Bus", "page_linlib.htm#section_user_guide_lin_intro", null ],
      [ "LIN Frame Identifiers", "page_linlib.htm#section_user_guide_lin_frame_identifiers", null ],
      [ "Where to go from here", "page_linlib.htm#section_user_guide_lin_where_to_go_from_here", null ]
    ] ],
    [ "J1587 API (J1587lib)", "page_j1587.htm", [
      [ "Description", "page_j1587.htm#section_user_guide_j1587_1", null ],
      [ "Where to go from here", "page_j1587.htm#section_user_guide_j1587_where_to_go_from_here", null ]
    ] ],
    [ "Database API (kvaDbLib)", "page_kvadblib.htm", "page_kvadblib" ],
    [ "Converter API (kvlclib)", "page_kvlclib.htm", "page_kvlclib" ],
    [ "Memorator API (kvmlib)", "page_kvmlib.htm", [
      [ "Description", "page_kvmlib.htm#section_user_guide_kvmlib_1", null ],
      [ "Naming convention", "page_kvmlib.htm#section_user_guide_kvmlib_2", null ],
      [ "Build an application", "page_kvmlib.htm#section_user_guide_kvmlib_3", null ],
      [ "Where to go from here", "page_kvmlib.htm#section_user_guide_kvmlib_where_to_go_from_here", null ]
    ] ],
    [ "Memorator XML API (kvaMemoLibXML)", "page_kvamemolibxml.htm", [
      [ "Description", "page_kvamemolibxml.htm#section_user_guide_kvamemolibxml_1", null ],
      [ "Build an application", "page_kvamemolibxml.htm#section_user_guide_kvamemolibxml_2", null ],
      [ "Where to go from here", "page_kvamemolibxml.htm#section_user_guide_kvamemolibxml_where_to_go_from_here", null ]
    ] ],
    [ "Remote Device API (kvrlib)", "page_kvrlib.htm", "page_kvrlib" ],
    [ "Deprecated List", "deprecated.htm", null ],
    [ "Modules", "modules.htm", "modules" ],
    [ "Data Structures", "annotated.htm", [
      [ "Data Structures", "annotated.htm", "annotated_dup" ],
      [ "Data Fields", "functions.htm", [
        [ "All", "functions.htm", null ],
        [ "Variables", "functions_vars.htm", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.htm", "files" ]
    ] ],
    [ "Examples", "examples.htm", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.htm",
"canlib_8h.htm#aa35b3f04d717c654cec0a4f0468ebf84",
"canstat_8h.htm#a52b5e5c71832b0bd3c6a5b1fd48583e7acd1c4c3a87dd24f0a43753ee4bfe7993",
"group___discovery.htm#gad14788125816240a858213203df33fbf",
"group___obsolete.htm#gad0f169d4007c3f56e4ca00a0c61010ce",
"group__kvadb__attributes.htm#ga537998cc1fd0bc2e8f2960d75f53b672",
"group__kvadb__signals.htm#gac592e48b7618d40d778698a5c21ed14d",
"group__kvm__rtc.htm#ga0545d8d9c2782728d263ed67cbc0efac",
"kva_db_lib_8h.htm#aca4f6042ed5df050dab2ff4278fc7270acc006914e40331c093e3278e0354d556",
"kvmlib_8h.htm#a78959352d1ef85550b7555521b70ef91",
"modules.htm"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';