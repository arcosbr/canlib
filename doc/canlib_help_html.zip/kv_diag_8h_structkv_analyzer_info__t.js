var kv_diag_8h_structkv_analyzer_info__t =
[
    [ "analyzerNo", "kv_diag_8h.htm#ab838a6bff9e3773ddcb5f79ed3eb68b8", null ],
    [ "type", "kv_diag_8h.htm#ac765329451135abec74c45e1897abf26", null ],
    [ "version_major", "kv_diag_8h.htm#a127884f2f1eab0890886401341e3c895", null ],
    [ "version_minor", "kv_diag_8h.htm#a572faf2098c53a548a02485a12c3a493", null ]
];