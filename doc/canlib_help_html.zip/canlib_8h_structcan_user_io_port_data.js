var canlib_8h_structcan_user_io_port_data =
[
    [ "portNo", "canlib_8h.htm#a3001cfa2429ae1926b29f0d14e7184e0", null ],
    [ "portValue", "canlib_8h.htm#acd5ef299b011d43a09b0f97f96edd444", null ]
];