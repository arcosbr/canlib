var kvamemolibxml_8h_struct_kv_parse_handle =
[
    [ "next", "kvamemolibxml_8h.htm#a68f64b5ffe49f617e182b80d771ae645", null ]
];