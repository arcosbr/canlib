var kv_diag_8h_structkv_diag_sample_8sample =
[
    [ "edgeCount", "kv_diag_8h.htm#a43bd3d02204ea3f0a8c3167714255fd6", null ],
    [ "edgeTimes", "kv_diag_8h.htm#ad728b3ab33048be8a7849f201be443a3", null ],
    [ "sampleFreq", "kv_diag_8h.htm#a4a86f4da890211fb87c354aabd886a7b", null ],
    [ "startTime", "kv_diag_8h.htm#a5b2a579f62087d17d79ce59f3de5f6d1", null ],
    [ "startValue", "kv_diag_8h.htm#a8444b1753d629219a099cbcf84afebce", null ]
];