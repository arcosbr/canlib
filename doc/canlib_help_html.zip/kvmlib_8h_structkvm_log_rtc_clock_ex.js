var kvmlib_8h_structkvm_log_rtc_clock_ex =
[
    [ "calendarTime", "kvmlib_8h.htm#a144eaa57942f3e7ff88a173437737edf", null ],
    [ "timeStamp", "kvmlib_8h.htm#aa1fa735b38f32cc201831ea72527ec37", null ]
];