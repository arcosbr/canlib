var kv_diag_8h_structkv_diag_sample =
[
    [ "header", "kv_diag_8h.htm#a9eb7b29f8ed7fb2e3b92859d95775885", null ],
    [ "msg", "kv_diag_8h.htm#a07cdc39365615c7c50cad3cdc5720cc5", null ],
    [ "sample", "kv_diag_8h.htm#a0ae8f530470846e02a08ed5410bad175", null ]
];