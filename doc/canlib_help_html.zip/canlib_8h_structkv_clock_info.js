var canlib_8h_structkv_clock_info =
[
    [ "accuracy_ppm", "canlib_8h.htm#a1ceb47504c247019604b4d4e05504a9e", null ],
    [ "denominator", "canlib_8h.htm#a6d7a01ea2b2b71b529a024b1a4617e3f", null ],
    [ "numerator", "canlib_8h.htm#afda10a8365f279d4d95a406787507bde", null ],
    [ "power_of_ten", "canlib_8h.htm#a67810cb57a3edc799ac9b23ebbe59457", null ],
    [ "version", "canlib_8h.htm#aad880fc4455c253781e8968f2239d56f", null ]
];