var kvmlib_8h_structkvm_log_event_ex =
[
    [ "eventUnion", "kvmlib_8h.htm#a414ecbd2781031ce8a4a4119b065d784", null ],
    [ "type", "kvmlib_8h.htm#af356674bbaaf9bb782af79059eef1346", null ]
];