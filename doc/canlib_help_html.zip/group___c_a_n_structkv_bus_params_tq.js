var group___c_a_n_structkv_bus_params_tq =
[
    [ "phase1", "group___c_a_n.htm#aa8c2aacf694615ddaff84e31b31ae0ff", null ],
    [ "phase2", "group___c_a_n.htm#a87167f9802ef5563e4236d5710e1b65b", null ],
    [ "prescaler", "group___c_a_n.htm#af263c600d546b48e74f8f7ac7a891533", null ],
    [ "prop", "group___c_a_n.htm#a4a8f6c91eefb9c6bf448592aac44153d", null ],
    [ "sjw", "group___c_a_n.htm#a3b769dc9a0e203dea3cc931bdb304377", null ],
    [ "tq", "group___c_a_n.htm#a4559f9255ccc9f785a33412fe5496d1a", null ]
];