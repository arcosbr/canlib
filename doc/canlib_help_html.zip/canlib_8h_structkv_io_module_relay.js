var canlib_8h_structkv_io_module_relay =
[
    [ "DI1", "canlib_8h.htm#ae673886a97b8bff94b37353d867360e2", null ],
    [ "DI2", "canlib_8h.htm#a21521922bb7239fc7fbc627dd978077f", null ],
    [ "DI3", "canlib_8h.htm#a47bc8c2f7dc265222cf1d92c52489aa2", null ],
    [ "DI4", "canlib_8h.htm#ad8ea363e8fb685db5b5092e83aaca8a1", null ],
    [ "DI5", "canlib_8h.htm#aeabb3a6a03548c179ed3206252324f37", null ],
    [ "DI6", "canlib_8h.htm#ad79655790f1a07f74631c556490add08", null ],
    [ "DI7", "canlib_8h.htm#aa787bce223b5e1bd54385456816d6df9", null ],
    [ "DI8", "canlib_8h.htm#a7e3ae6d77be430378addccb0436507af", null ],
    [ "RO1", "canlib_8h.htm#a51f47034125d484b8a7d13e414f2854a", null ],
    [ "RO2", "canlib_8h.htm#a74ec56c96381bdbac5979ca55f1f6c81", null ],
    [ "RO3", "canlib_8h.htm#a5b25e1ffac3bdd23e1b7be606abfd437", null ],
    [ "RO4", "canlib_8h.htm#ab3f579cac16905edf55011dcc2e9090a", null ],
    [ "RO5", "canlib_8h.htm#a2a2866e10a2945ebd13e09bcbb57cd52", null ],
    [ "RO6", "canlib_8h.htm#ac8627cecb81615ec17028f05c2faf449", null ],
    [ "RO7", "canlib_8h.htm#a459a1901794b9ff25b154c25696a14c4", null ],
    [ "RO8", "canlib_8h.htm#a9fcce63e7449e5adb9ae98deaaf5efee", null ],
    [ "type", "canlib_8h.htm#ac765329451135abec74c45e1897abf26", null ]
];