var group__grp__kvlc =
[
    [ "Converter", "group__kvlc__converter.htm", "group__kvlc__converter" ],
    [ "Output Formats", "group__kvlc__output.htm", "group__kvlc__output" ],
    [ "Memorator", "group__kvlc__memorator.htm", "group__kvlc__memorator" ],
    [ "Database", "group__kvlc__database.htm", "group__kvlc__database" ]
];