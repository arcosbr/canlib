var kv_diag_8h =
[
    [ "bitrate_t", "kv_diag_8h.htm#structbitrate__t", [
      [ "bitrate", "kv_diag_8h.htm#a8cbd72632a1cb167e5ca769b067cfcec", null ],
      [ "quality", "kv_diag_8h.htm#acac7df77df55f2a1bfd8d8d18340b773", null ]
    ] ],
    [ "bitrates_t", "kv_diag_8h.htm#structbitrates__t", [
      [ "bitrate", "kv_diag_8h.htm#a9b69ac1d9a035cf32487c02eb1e90368", null ],
      [ "bitrate_brs", "kv_diag_8h.htm#a52ce335bfc68ea72b4b213625c875981", null ]
    ] ],
    [ "kvDiagSample", "kv_diag_8h.htm#structkv_diag_sample", [
      [ "header", "kv_diag_8h.htm#a9eb7b29f8ed7fb2e3b92859d95775885", null ],
      [ "msg", "kv_diag_8h.htm#a07cdc39365615c7c50cad3cdc5720cc5", null ],
      [ "sample", "kv_diag_8h.htm#a0ae8f530470846e02a08ed5410bad175", null ]
    ] ],
    [ "kvAnalyzerInfo_t", "kv_diag_8h.htm#structkv_analyzer_info__t", [
      [ "analyzerNo", "kv_diag_8h.htm#ab838a6bff9e3773ddcb5f79ed3eb68b8", null ],
      [ "type", "kv_diag_8h.htm#ac765329451135abec74c45e1897abf26", null ],
      [ "version_major", "kv_diag_8h.htm#a127884f2f1eab0890886401341e3c895", null ],
      [ "version_minor", "kv_diag_8h.htm#a572faf2098c53a548a02485a12c3a493", null ]
    ] ],
    [ "kvDiagSample.header", "kv_diag_8h.htm#structkv_diag_sample_8header", [
      [ "seqno", "kv_diag_8h.htm#ad8d8c9e3082c9d3cc78d718b0d250891", null ],
      [ "type", "kv_diag_8h.htm#a599dcce2998a6b40b1e38e8c6006cb0a", null ],
      [ "version", "kv_diag_8h.htm#a2af72f100c356273d46284f6fd1dfc08", null ]
    ] ],
    [ "kvDiagSample.msg", "kv_diag_8h.htm#structkv_diag_sample_8msg", [
      [ "data", "kv_diag_8h.htm#ad86924571a9ec796dff8751832d99c9b", null ],
      [ "dlc", "kv_diag_8h.htm#a95e10614fcf9d33c1d95a17cd02d2303", null ],
      [ "flag", "kv_diag_8h.htm#a327a6c4304ad5938eaf0efb6cc3e53dc", null ],
      [ "id", "kv_diag_8h.htm#ab80bb7740288fda1f201890375a60c8f", null ],
      [ "time", "kv_diag_8h.htm#a07cc694b9b3fc636710fa08b6922c42b", null ]
    ] ],
    [ "kvDiagSample.sample", "kv_diag_8h.htm#structkv_diag_sample_8sample", [
      [ "edgeCount", "kv_diag_8h.htm#a43bd3d02204ea3f0a8c3167714255fd6", null ],
      [ "edgeTimes", "kv_diag_8h.htm#ad728b3ab33048be8a7849f201be443a3", null ],
      [ "sampleFreq", "kv_diag_8h.htm#a4a86f4da890211fb87c354aabd886a7b", null ],
      [ "startTime", "kv_diag_8h.htm#a5b2a579f62087d17d79ce59f3de5f6d1", null ],
      [ "startValue", "kv_diag_8h.htm#a8444b1753d629219a099cbcf84afebce", null ]
    ] ],
    [ "DIAG_ANALYZER_TYPE_DEFAULT", "kv_diag_8h.htm#a29188edd320816f6f3b4e98e6b331a66", null ],
    [ "DIAG_PROGRAM_TYPE_AUTOBAUD", "kv_diag_8h.htm#a64bb36d4e56a896eb2af5dc09cce1542", null ],
    [ "DIAG_PROGRAM_TYPE_NORMAL", "kv_diag_8h.htm#ad24c2e14068b790b7b105c6423e42400", null ],
    [ "kvDiagAttachAnalyzer", "group__kvdiag__diagnostics.htm#ga76d09ccb89cf756d954144582f730330", null ],
    [ "kvDiagCalculateBitrate", "group__kvdiag__diagnostics.htm#gabc77cf695c7fb518263d32539a3aec9e", null ],
    [ "kvDiagCalculateClockOffset", "group__kvdiag__diagnostics.htm#ga243548139dcbb64ff273648dd0c370dd", null ],
    [ "kvDiagDetachAnalyzer", "group__kvdiag__diagnostics.htm#ga61263295b3feaad95c257eef05a9579b", null ],
    [ "kvDiagGetAnalyzerInfo", "group__kvdiag__diagnostics.htm#ga348f389077d77b8fd4cf04ad53558aad", null ],
    [ "kvDiagGetNumberOfAnalyzers", "group__kvdiag__diagnostics.htm#ga926f63f2ccb0b56ff4917151ab5e27fe", null ],
    [ "kvDiagReadSample", "group__kvdiag__diagnostics.htm#ga43a268ee89c38c3ac496d20f35a48105", null ],
    [ "kvDiagReadSampleWait", "group__kvdiag__diagnostics.htm#gaab9b2bc0856a7200d1f76533092eb023", null ],
    [ "kvDiagResetBitrateCalculation", "group__kvdiag__diagnostics.htm#ga65bbdc1e8c8bf4affc8ba2041d72ff1a", null ],
    [ "kvDiagResetClockOffsetCalculation", "group__kvdiag__diagnostics.htm#ga1708e589eb731c11c82a621b2a070d1d", null ],
    [ "kvDiagSetProgram", "group__kvdiag__diagnostics.htm#gad615ea3768542e4d48f10d0dca4ef46d", null ],
    [ "kvDiagStart", "group__kvdiag__diagnostics.htm#ga9cb62a80b9ffe4ea80b22acfb49bd3a4", null ],
    [ "kvDiagStop", "group__kvdiag__diagnostics.htm#ga685c95a3e168601a28e680d9c820dd8a", null ]
];