var canlib_8h_structkv_io_module_internal =
[
    [ "DI", "canlib_8h.htm#a92162ee960f0e92fd68cca9838f05e3d", null ],
    [ "DO", "canlib_8h.htm#ab0a26d3fc12f25e409e5676ac4ce2697", null ],
    [ "type", "canlib_8h.htm#ac765329451135abec74c45e1897abf26", null ]
];