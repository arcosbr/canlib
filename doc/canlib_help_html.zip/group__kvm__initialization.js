var group__kvm__initialization =
[
    [ "kvmGetErrorText", "group__kvm__initialization.htm#ga87d29e88308410be0066473c9e975480", null ],
    [ "kvmGetVersion", "group__kvm__initialization.htm#gaefbd601765b093d2e748c96191048a07", null ],
    [ "kvmInitialize", "group__kvm__initialization.htm#ga59f41146c0cbea69a936edc1cdd6ebae", null ]
];