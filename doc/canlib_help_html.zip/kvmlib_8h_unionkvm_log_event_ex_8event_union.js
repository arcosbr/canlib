var kvmlib_8h_unionkvm_log_event_ex_8event_union =
[
    [ "msg", "kvmlib_8h.htm#a6e2baaf3b97dbeef01c0043275f9a0e7", null ],
    [ "raw", "kvmlib_8h.htm#ae5f6e01a333a527bc8c60b6aec1798a6", null ],
    [ "rtc", "kvmlib_8h.htm#a68154466f81bfb532cd70f8c71426356", null ],
    [ "trig", "kvmlib_8h.htm#a3d1b2de7201c79e0139783125aec4cd6", null ],
    [ "ver", "kvmlib_8h.htm#a0812f14f43315611dd0ef462515c9d00", null ]
];