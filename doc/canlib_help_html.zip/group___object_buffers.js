var group___object_buffers =
[
    [ "canObjBufAllocate", "group___object_buffers.htm#gacfd23956af809dfc6db822c2f5ba25e7", null ],
    [ "canObjBufDisable", "group___object_buffers.htm#gaeb6e506db100de24d556ab65c2fcb593", null ],
    [ "canObjBufEnable", "group___object_buffers.htm#ga3e145ec233501345db191ae715a09cb4", null ],
    [ "canObjBufFree", "group___object_buffers.htm#ga2a7e7c895e41b20da47aa850712d264a", null ],
    [ "canObjBufFreeAll", "group___object_buffers.htm#gaf836ebe16681215a3a40defa3a9d81ad", null ],
    [ "canObjBufSendBurst", "group___object_buffers.htm#ga8385ea3d2278fb45cf2a11042940b92b", null ],
    [ "canObjBufSetFilter", "group___object_buffers.htm#ga16a648123fbc05b8c4a2a46d7d7e1c2c", null ],
    [ "canObjBufSetFlags", "group___object_buffers.htm#ga802fdc1accf0124b0b442623c6668f41", null ],
    [ "canObjBufSetMsgCount", "group___object_buffers.htm#gaab0389f48769a91f540d2b97e8fd031b", null ],
    [ "canObjBufSetPeriod", "group___object_buffers.htm#ga9285a2316c11bc17ec2a98ab64812ce5", null ],
    [ "canObjBufWrite", "group___object_buffers.htm#ga9b0e3dffd54e5abdd6972dd468353022", null ]
];