var kva_db_lib_8h_struct_kva_db_protocol_properties =
[
    [ "maxMessageDlc", "kva_db_lib_8h.htm#acea8c05d06bb3303dd71b41bec875533", null ],
    [ "maxSignalLength", "kva_db_lib_8h.htm#a4f81fb4d85cd39f1658a64e087321245", null ]
];