var group__kvaxml__initialization =
[
    [ "kvaXmlGetLastError", "group__kvaxml__initialization.htm#gaf74346d43e00440173c84f78b2dbf0f0", null ],
    [ "kvaXmlInitialize", "group__kvaxml__initialization.htm#ga0b3e78afddf41c2c096af41fbcea1ba7", null ]
];