var group__grp__kvrlib =
[
    [ "Local configuration", "group___configuration.htm", "group___configuration" ],
    [ "Network information", "group___network.htm", "group___network" ],
    [ "Device Discovery", "group___discovery.htm", "group___discovery" ],
    [ "Helper functions", "group___helper.htm", "group___helper" ]
];