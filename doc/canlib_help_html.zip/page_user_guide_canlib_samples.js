var page_user_guide_canlib_samples =
[
    [ "Monitor CAN channel", "page_example_c_candump.htm", null ],
    [ "List CAN channels", "page_example_c_channeldata.htm", null ],
    [ "Receive and reply to CAN message", "page_example_c_echo.htm", null ],
    [ "Multi threading in CANlib", "page_example_c_threads.htm", null ],
    [ "Echo server", "page_example_c_canecho.htm", null ],
    [ "Send database signal", "page_example_c_gensig.htm", null ],
    [ "High frequency sampling with CANtegrity", "page_example_c_kvdiag_normal.htm", null ],
    [ "Bitrate calculation with CANtegrity", "page_example_c_kvdiag_autobaud.htm", null ]
];