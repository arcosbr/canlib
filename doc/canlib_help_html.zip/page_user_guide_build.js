var page_user_guide_build =
[
    [ "Compatibility", "page_user_guide_build.htm#section_porting_code_older", null ],
    [ "Compiling and Linking on Windows", "page_user_guide_build_compiling_linking_windows.htm", [
      [ "Compiling and Linking Your Code on Windows", "page_user_guide_build_compiling_linking_windows.htm#section_user_guide_build_compiling_linking_windows", null ],
      [ "Deploying Your Application", "page_user_guide_build_compiling_linking_windows.htm#section_user_guide_build_installation_deploy", null ],
      [ "Redistributable Files in CANlib SDK", "page_user_guide_build_compiling_linking_windows.htm#section_user_guide_intro_redistributable", null ]
    ] ],
    [ "Compiling and Linking on Linux", "page_user_guide_build_compiling_linking_linux.htm", [
      [ "Linking Your Code on Linux", "page_user_guide_build_compiling_linking_linux.htm#section_user_guide_build_compiling_linking_linux", null ]
    ] ]
];