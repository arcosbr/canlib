var kv_diag_8h_structkv_diag_sample_8header =
[
    [ "seqno", "kv_diag_8h.htm#ad8d8c9e3082c9d3cc78d718b0d250891", null ],
    [ "type", "kv_diag_8h.htm#a599dcce2998a6b40b1e38e8c6006cb0a", null ],
    [ "version", "kv_diag_8h.htm#a2af72f100c356273d46284f6fd1dfc08", null ]
];