var modules =
[
    [ "CANlib", "group__grp__canlib.htm", "group__grp__canlib" ],
    [ "LINlib", "group__grp__linlib.htm", "group__grp__linlib" ],
    [ "J1587", "group__grp__j1587.htm", "group__grp__j1587" ],
    [ "kvaDbLib", "group__grp__kvadb.htm", "group__grp__kvadb" ],
    [ "kvlclib", "group__grp__kvlc.htm", "group__grp__kvlc" ],
    [ "kvmlib", "group__grp__kvm.htm", "group__grp__kvm" ],
    [ "kvaMemoLibXML", "group__grp__kvaxml.htm", "group__grp__kvaxml" ],
    [ "kvrlib", "group__grp__kvrlib.htm", "group__grp__kvrlib" ]
];