var kvrlib_8h_structkvr_address =
[
    [ "address", "kvrlib_8h.htm#afd449f94a650582f7a2d0a4bcd14928a", null ],
    [ "type", "kvrlib_8h.htm#ad44b615021ed3ccb734fcaf583ef4a03", null ]
];