var kv_diag_8h_structbitrate__t =
[
    [ "bitrate", "kv_diag_8h.htm#a8cbd72632a1cb167e5ca769b067cfcec", null ],
    [ "quality", "kv_diag_8h.htm#acac7df77df55f2a1bfd8d8d18340b773", null ]
];