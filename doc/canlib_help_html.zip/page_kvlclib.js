var page_kvlclib =
[
    [ "Introduction", "kvlclib_introduction.htm", [
      [ "Naming convention", "kvlclib_introduction.htm#section_user_guide_kvlclib_2", null ],
      [ "Build an application", "kvlclib_introduction.htm#kvlclib_section_build_an_application", null ]
    ] ],
    [ "Converting", "kvlclib_converting.htm", [
      [ "Hello kvlclib", "kvlclib_converting.htm#kvlclib_hello_kvlclib", null ]
    ] ],
    [ "Properties", "kvlclib_properties.htm", [
      [ "Checking property defaults", "kvlclib_properties.htm#kvlclib_section_checking_property_defaults", null ],
      [ "Setting properties", "kvlclib_properties.htm#kvlclib_section_setting_properties", null ],
      [ "Checking properties", "kvlclib_properties.htm#kvlclib_section_checking_properties", null ]
    ] ],
    [ "Supported Formats", "kvlclib_formats.htm", "kvlclib_formats" ]
];