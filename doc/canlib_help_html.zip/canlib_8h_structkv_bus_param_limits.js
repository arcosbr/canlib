var canlib_8h_structkv_bus_param_limits =
[
    [ "arbitration_max", "canlib_8h.htm#a6d10a8e3c78ce93fa4c4c2ab206a817d", null ],
    [ "arbitration_min", "canlib_8h.htm#a704d465cdedf10c17c6e61884b6d76ff", null ],
    [ "data_max", "canlib_8h.htm#ac989469cbc0ab9cae6da7801f11d4be0", null ],
    [ "data_min", "canlib_8h.htm#aca75b9806920539ceea834b9ca411495", null ],
    [ "version", "canlib_8h.htm#aad880fc4455c253781e8968f2239d56f", null ]
];