var group__t_script =
[
    [ "kvScriptEnvvarClose", "group__t_script.htm#ga30f88cbfc588c801f8bf4c81c094875c", null ],
    [ "kvScriptEnvvarGetData", "group__t_script.htm#ga5cbb37e43a2e24358c63295fedfe06a3", null ],
    [ "kvScriptEnvvarGetFloat", "group__t_script.htm#gafee8ff7e33041bee5f523115aae7f59e", null ],
    [ "kvScriptEnvvarGetInt", "group__t_script.htm#gacf9775ec635485786a4afb3cb77ce94e", null ],
    [ "kvScriptEnvvarOpen", "group__t_script.htm#ga1f4f192b6b486e2cc62ebf162a040e77", null ],
    [ "kvScriptEnvvarSetData", "group__t_script.htm#ga5d81bb016783417bbb90cee739fed5a4", null ],
    [ "kvScriptEnvvarSetFloat", "group__t_script.htm#ga0e1f89bb27cb2041643e9e97efd47839", null ],
    [ "kvScriptEnvvarSetInt", "group__t_script.htm#gaef0cffb28882fa9a731cda884ea8332c", null ],
    [ "kvScriptGetMaxEnvvarSize", "group__t_script.htm#gafe38fc6634a1743f404001def0ffa392", null ],
    [ "kvScriptGetText", "group__t_script.htm#gab9c6a1fc7fd430bf101ee3fea7b9a3ac", null ],
    [ "kvScriptLoadFile", "group__t_script.htm#ga836f264e247e16b3d4ea1a025597cef3", null ],
    [ "kvScriptLoadFileOnDevice", "group__t_script.htm#ga4b94293f0c19729e8471e43365e8b535", null ],
    [ "kvScriptRequestText", "group__t_script.htm#gaa32fac50302a1dc190753b2fe918213c", null ],
    [ "kvScriptSendEvent", "group__t_script.htm#ga17a485eb7bd6f827272b1e5199d8e828", null ],
    [ "kvScriptStart", "group__t_script.htm#ga18554bbb583f0c869f749b94464b7c18", null ],
    [ "kvScriptStatus", "group__t_script.htm#gafd614d2af0782de6f59ff33fa7100c57", null ],
    [ "kvScriptStop", "group__t_script.htm#gab354b2471f49116c042a7e07a09754d8", null ],
    [ "kvScriptTxeGetData", "group__t_script.htm#ga442c63a2cddbf96ffa0a100e9d9e4283", null ],
    [ "kvScriptUnload", "group__t_script.htm#gafd6f526de1787883abcf6c135476366a", null ]
];