var group___discovery =
[
    [ "kvrDeviceGetServiceStatus", "group___discovery.htm#gaf17a1ee475ab65e1773c2edf851e5aa8", null ],
    [ "kvrDeviceGetServiceStatusText", "group___discovery.htm#ga0c8461e07e555a47293e700b71b79d76", null ],
    [ "kvrDiscoveryClearDevicesAtExit", "group___discovery.htm#ga8fbbaf90689d4dee244edddd7bc14ee0", null ],
    [ "kvrDiscoveryClose", "group___discovery.htm#ga787488cf05c964fbde96346c297e112a", null ],
    [ "kvrDiscoveryGetDefaultAddresses", "group___discovery.htm#ga387fae851acdcf59aef62f16ac59b233", null ],
    [ "kvrDiscoveryGetResults", "group___discovery.htm#ga0d0f19cb2e156c82f70f42fcf958da25", null ],
    [ "kvrDiscoveryOpen", "group___discovery.htm#gaa27f34a126fd04d13e4e6745a11beb46", null ],
    [ "kvrDiscoverySetAddresses", "group___discovery.htm#ga122ec5535fef74d035c727365686e886", null ],
    [ "kvrDiscoverySetEncryptionKey", "group___discovery.htm#ga81a54e4b2a58ddbefb3ec13b8b149cc2", null ],
    [ "kvrDiscoverySetPassword", "group___discovery.htm#ga8c938eed8a528b7c5ffbf9faa298a9a0", null ],
    [ "kvrDiscoveryStart", "group___discovery.htm#gad14788125816240a858213203df33fbf", null ],
    [ "kvrDiscoveryStartEx", "group___discovery.htm#ga1f2f51f06410c084419482faa3bac7df", null ],
    [ "kvrDiscoveryStoreDevices", "group___discovery.htm#ga8517ee0d846a9a14ddf34f4c881e59dd", null ]
];